// fitvids to make all videos full width http://fitvidsjs.com/  
(function($) {
	"use strict";
	$(function() {
		$('.the-content').fitVids();	
	});
}(jQuery));